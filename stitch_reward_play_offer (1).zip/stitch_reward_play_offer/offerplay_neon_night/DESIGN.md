---
name: OfferPlay Neon Night
colors:
  surface: '#141121'
  surface-dim: '#141121'
  surface-bright: '#3b3749'
  surface-container-lowest: '#0f0c1c'
  surface-container-low: '#1d192a'
  surface-container: '#211d2e'
  surface-container-high: '#2b2839'
  surface-container-highest: '#363244'
  on-surface: '#e6dff7'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e6dff7'
  inverse-on-surface: '#322e40'
  outline: '#958ea0'
  outline-variant: '#494454'
  surface-tint: '#d0bcff'
  primary: '#d0bcff'
  on-primary: '#3c0091'
  primary-container: '#a078ff'
  on-primary-container: '#340080'
  inverse-primary: '#6d3bd7'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#00a572'
  on-tertiary-container: '#00311f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e9ddff'
  primary-fixed-dim: '#d0bcff'
  on-primary-fixed: '#23005c'
  on-primary-fixed-variant: '#5516be'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#141121'
  on-background: '#e6dff7'
  surface-variant: '#363244'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.05em
  numeric-balance:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system is crafted for a hyper-engaging mobile gaming rewards platform that merges the playful thrill of casual arcade mechanics with the genuine excitement of real financial value. Target users are digital-native Gen Z and millennial mobile gamers who appreciate high-energy visual feedback, instant gratification, and friendly, accessible onboarding. 

The aesthetic is **Cyber-Glass Arcade**: a fusion of deep nocturnal indigo backdrops, translucent glass containers, neon violet bioluminescent glows, and lustrous metallic coin accents. The experience is anchored by a friendly, mischievous purple ghost mascot that guides users through reward milestones, daily spin streaks, and withdrawal confirmations. The visual environment balances rich, luminous delight with structured data clarity—ensuring balances, tasks, and payouts remain instantly decipherable at a glance.

Bilingual copy integration seamlessly blends natural conversational Hindi and direct English action drivers (e.g., "Khel Kar Kamayein", "Instant Bank Redeem", "Daily Streak Flame"), creating an authentic, localized, and emotionally resonant vernacular for mobile users.

## Colors

The palette revolves around deep, atmospheric darks punctuated by electric purples and radiant reward golds.

- **Primary Canvas & Surfaces**: Base backdrop starts at `#0B0818` (Obsidian Violet), transitioning to `#130E2E` (Deep Midnight Indigo) for elevated viewports. Card surfaces utilize `#1B143D` at variable opacity levels paired with a crisp 1px `#2E2260` inner structural stroke.
- **Neon Energy Accent (Primary)**: `#8B5CF6` (Vivid Purple) and `#A855F7` (Electric Violet) drive high-priority user actions, streak milestones, mascot glow highlights, and active bottom navigation states.
- **Reward Currency & Coins (Secondary)**: `#F59E0B` (Rich Amber) supported by `#FBBF24` (Sunburst Gold) and `#FCD34D` (Coin Highlight) reserved strictly for coin balances, cash-out tickers, rupee/reward amounts, and streak flame heat indicators.
- **Success & Progression (Tertiary)**: `#10B981` (Emerald Green) signals completed tasks, successful withdrawals, and positive ROI gaming multipliers.
- **Status & Danger**: `#EF4444` (Crimson Fire) reserved for broken streaks, timer expirations, and balance warnings.
- **Neutrals & Text Tiers**: High-contrast white `#FFFFFF` for primary values, muted lilac `#C4B5FD` for secondary captions, and `#6D6594` for disabled states and subtle scaffolding.

## Typography

The design system utilizes **Plus Jakarta Sans** across all hierarchies. Its wide counters, clean geometric rhythm, and contemporary rounded nuances provide maximum legibility on mobile viewports while projecting an approachable, modern game-centric voice. 

- **Display & Coin Numerics**: Bold weights (700–800) ensure instant currency visibility when paired with rupee (`₹`) and coin glyphs. Font tracking is dialed tight (`-0.02em`) on headline ranks to retain punchy visual strength.
- **Bilingual Vernacular**: Hindi transliterations and mixed phrasing ("Rozana Bonus", "Turant Redeem Karein") receive identical typographic scale to Latin text, maintaining consistent baseline grids and vertical spacing rhythms.
- **Labels & Micro-Badges**: Small label tiers (`label-sm`, 10px) utilize uppercase formatting and generous letter-spacing (`+0.05em`) for game difficulty tags, multiplier indicators (e.g., `2X COINS`), and promotional tags.

## Layout & Spacing

The layout operates on an 8pt base grid optimized for mobile ergonomics and one-handed thumb interaction. 

- **Grid & Safe Zones**: Native mobile screens enforce a 4-column layout with `16px` (`1rem`) outer margins and `16px` gutters. Interactive elements maintain an uninterrupted 56px bottom offset above the floating tab bar to preserve safe-touch navigation.
- **Component Padding Scale**: Internal card paddings default to `space-lg` (16px), while tight micro-chips and status tags scale down to `space-xs` (4px vertical) and `space-sm` (8px horizontal).
- **Responsive Stacking**: Horizontal task rails (e.g., "Trending Games", "Daily Offers") switch from side-scrolling cards with peek-previews (85% viewport width) on mobile devices to a structured 2-column or 3-column auto-fill grid on tablet viewports.

## Elevation & Depth

Visual depth is achieved through layered frosted glass combined with targeted neon luminescence:

1. **Base Tier (Ground 0)**: Background canvases feature subtle diagonal radial gradients radiating from the mascot header (`#130E2E` descending to `#0B0818`).
2. **Glass Tier 1 (Cards & Lists)**: `#1B143D` at 75% opacity with an active `backdrop-filter: blur(16px)` and an omnidirectional border (`1px solid #2E2260`). Zero heavy black drop-shadows are used.
3. **Floating Tier 2 (Bottom Bar, Sticky Balances, Modals)**: `#171038` at 90% opacity, bordered by `1px solid #43337E`, cast with a diffused ambient glow: `0px 12px 32px rgba(139, 92, 246, 0.2)`.
4. **Interactive Neon Highlights**: Clickable primary buttons and streak indicators project a localized atmospheric halo using `box-shadow: 0 0 20px rgba(139, 92, 246, 0.45)`.
5. **Gold Currency Halo**: Coin accumulation badges and claim modules emit an internal and external warm radiance: `box-shadow: 0 0 16px rgba(245, 158, 11, 0.35)`.

## Shapes

The design system embraces a **Rounded** aesthetic (Level 2), harmonizing fluid, approachable curvature with gaming console interfaces:

- **Cards & Offer Modules**: Default to `16px` (`rounded-lg`), delivering friendly tactile containers for game cover art, progress bars, and redemption vouchers.
- **Buttons & Interactive Tags**: Primary action triggers, filter chips, and balance counters adopt full pill shapes (`rounded-full` / `9999px`) to invite natural thumb taps.
- **Game Badges & Icons**: Game app icons and reward chest thumbnails carry smooth `12px` rounded squircle corners.
- **Modals & Bottom Sheets**: Top edges utilize `24px` (`rounded-xl`) radii for seamless sliding drawer transitions.

## Components

### Buttons & Action Controls
- **Primary CTA ("Khel Kar Kamayein" / "Redeem")**: Vibrant gradient fill (`linear-gradient(135deg, #8B5CF6, #6D28D9)`), white bold typography, pill radius, and an ambient purple glow. Pressed states scale down slightly to `0.97` with an intensified backlight.
- **Secondary Coin Button**: Outlined in `1px solid #F59E0B`, filled with translucent amber (`rgba(245, 158, 11, 0.1)`), featuring shimmering gold text and coin icon prefix.

### Wallet & Balance Display
- Prominently anchored at the top-right or hero panel. Translucent glass pill container framed in `#2E2260`. Contains coin vector icon, numeric value in `numeric-balance` font, and dual subtext ("Total Balance / Kul Kamai") in `#C4B5FD`.

### Glass Cards & Offer Lists
- Constructed from `#1B143D` at 80% opacity with `1px #2E2260` borders. Houses the game's high-res icon, reward title, payout potential badge (e.g., `+₹150`), and micro-progress track.

### Daily Streak Flame & Mascot Interstitials
- Dedicated streak tracker featuring sequential pill chips for Days 1 through 7. Active and completed streak days illuminate with a glowing fire icon (`#F59E0B` to `#EF4444` gradient fill).
- The friendly purple ghost mascot appears in modal headers and empty states, projecting a soft animated violet aura (`#A855F7`).

### Bottom Navigation Bar
- Docked frosted panel (`#130E2E` at 92% opacity, blurred background). Active icons trigger a luminous purple dot indicator with a radial neon backlight (`rgba(168, 85, 247, 0.35)`) and bold text in `#A855F7`. Inactive states rest in muted `#6D6594`.

### Form Fields & Redemption Inputs
- Darkened inset backgrounds (`#0F0B24`) with `1px #2E2260` resting border, transforming to an electric violet outline (`#8B5CF6`) with a 4px soft outer glow upon focus.